nums = []
c = 0
a = True
run = True 
while run:
  value = input("Enter a number to sort or type done to finish ")
  if value == "done":
   nums.sort()
   print(nums)
   nums = []
   c =1
   run = False
  if c == 0:
   value2 = int(value)
   if value2 == int(value):
    nums.append(value2)
while a:
  if run == False:
    reset = input("do you want to sort another list press yes or no")
    if reset == "yes":
     run = True 
     while run:
      value = input("Enter a number to sort or type done to finish ")
      c = 0
      if value == "done":
       nums.sort()
       print(nums)
       nums = []
       c =1
       run = False
      if c == 0:
       value2 = int(value)
       if value2 == int(value):
        nums.append(value2)
    elif reset == "no":
      a = False 
      print("you are done with sorting lists")
    else:
      a = True